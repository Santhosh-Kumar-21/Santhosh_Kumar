﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ExitExamProject.Models
{
    public class Enrollment
    {
        public int Id { get; set; }

        [ForeignKey("Student")]
        public int StudentId { get; set; }

        [ForeignKey("Course")]
        public int CourseId { get; set; }

        public DateTime EnrollmentDate { get; set; }=DateTime.Now;

        public  Student Student { get; set; }

        public Course Course { get; set; }

    }
}

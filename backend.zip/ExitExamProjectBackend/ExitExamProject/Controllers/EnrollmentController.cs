﻿using ExitExamProject.Data;
using ExitExamProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExitExamProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {

        private readonly ApplicationDbContext _context;

        public EnrollmentController(ApplicationDbContext context)
        {
            _context = context;
        }


        [HttpGet("GetEnrollments/{studentId}")]
        public async Task<IActionResult> GetEnrollments(int studentId)
        {
            var res= await _context.Enrollments
                      .Where(e=> e.StudentId == studentId)
                      .Include(e=> e.Course)
                      .Select(e=> e.Course)
                      .ToListAsync();
            return Ok(res);

        }


        [HttpPost("AddEnrollments")]
        public async Task<ActionResult<Enrollment>> AddEnrollments([FromBody] Enrollment enrollment)
        {
            if (await _context.Enrollments.AnyAsync(e => e.StudentId == enrollment.StudentId && e.CourseId == enrollment.CourseId))
            {
                return BadRequest("This student is already enrolled in this course.");
            }

            _context.Enrollments.Add(enrollment);
            await _context.SaveChangesAsync();
            return Ok(enrollment);
        }

        
    }
}

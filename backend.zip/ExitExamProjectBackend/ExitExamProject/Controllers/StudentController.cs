﻿using ExitExamProject.Data;
using ExitExamProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace ExitExamProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }


        [HttpGet("GetStudents")]
        public async Task<IActionResult> GetStudents()
        {
            var res= await _context.Students.ToListAsync();
            return Ok(res); 
        }


        [HttpPost("AddStudent")]

        public async Task<IActionResult> AddStudent([FromBody] Student student)
        {
            _context.Students.Add(student);
            await _context.SaveChangesAsync();
            return Ok(student);
        }

        
    }
}

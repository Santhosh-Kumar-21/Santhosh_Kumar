﻿using ExitExamProject.Data;
using ExitExamProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace ExitExamProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CourseController(ApplicationDbContext context)
        {
            _context = context;
        }


        [HttpGet("GetCourses")]
        public async Task<IActionResult> GetCourses()
        {
            var res= await _context.Courses.ToListAsync();
            return Ok(res);
        }


        [HttpPost("AddCourse")]

        public async Task<IActionResult> AddCourse([FromBody] Course course)
        {
            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return Ok(course);
        }
    }
}
